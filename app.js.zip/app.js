let hunger=80;
let happiness=50;
let energy=40;

function displayInfo(){
    document.getElementById("hungerInfo").innerHTML=`JS-Hunger ${hunger}`; 
    document.getElementById("happinessInfo").innerHTML=`JS-Happiness ${happiness}`; 
    document.getElementById("energyInfo").innerHTML=`JS-Energy ${energy}`; 
    

}

function feed(){
    console.log("Feed Function");
    hunger=hunger-25;
    happiness=happiness+40;

    displayInfo();
}

function pet(){
    console.log("Feed Function");
    hunger=hunger-30;
    happiness=happiness+2;

    displayInfo();

}

function play(){
    console.log("Feed Function");
    hunger=hunger-17;
    happiness=happiness+57;

    displayInfo();

}

displayInfo();
